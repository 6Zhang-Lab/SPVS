library(SPVS)

setwd("/work/zzh/ZKN/AS模型")

Sys.setenv(
  SPVS_PYTHON = "/work/lzj/miniconda3/envs/scanpy_env/bin/python"
)

res <- run_spvs_on_spatial(
  input = "/data/public/scRNA/Aging/aging_artery/Visium_Slides_Novo_Atherosclerosis.h5ad",
  input_type = "h5ad",
  sample_id = "FW104302",
  out_dir = "PB_SDM/SPVS_package_demo_FW104302"
)

cat("SPVS FW104302 example completed.\n")
cat("Main figures are in: PB_SDM/SPVS_package_demo_FW104302/figures\n")
cat("Main tables are in: PB_SDM/SPVS_package_demo_FW104302/tables\n")
