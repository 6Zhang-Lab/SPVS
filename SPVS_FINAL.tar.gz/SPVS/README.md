# SPVS

**SPVS** is a standalone R package implementing an interpretable **Spatial Plaque Vulnerability State model** for spatial transcriptomics of atherosclerotic plaques.

Given a user's own spatial transcriptomics sample, SPVS can:

1. infer plaque-core-like molecular vulnerability states,
2. define **BND_IFTCore / PVI** as a graph-calibrated Plaque Vulnerability Interface,
3. visualize the 3-class spatial architecture on H&E background,
4. summarize boundary-associated cell-state and functional ecology.

SPVS is a standalone model. It does **not** require project-specific Step10E, Step10G0D, or manually prepared boundary labels.

---

## Installation

```r
install.packages(c(
  "dplyr", "tidyr", "readr", "ggplot2", "stringr",
  "scales", "FNN", "igraph", "Matrix", "magrittr"
))

install.packages(
  "SPVS_FINAL.tar.gz",
  repos = NULL,
  type = "source"
)
```

For H5AD input, SPVS calls Python/anndata. Set a Python executable containing `anndata`, `numpy`, `pandas`, and `scipy`:

```r
Sys.setenv(SPVS_PYTHON = "/path/to/python_with_anndata")
```

Test Python:

```r
system2(
  Sys.getenv("SPVS_PYTHON"),
  c("-c", shQuote("import anndata, pandas, numpy, scipy; print('ok')")),
  stdout = TRUE,
  stderr = TRUE
)
```

---

## Quick start

```r
library(SPVS)

Sys.setenv(
  SPVS_PYTHON = "/path/to/python_with_anndata"
)

res <- run_spvs_on_spatial(
  input = "/path/to/spatial_sample.h5ad",
  input_type = "h5ad",
  sample_id = "Sample01",
  out_dir = "SPVS_results"
)
```

The standalone default parameters are already tuned and do not need to be specified by users:

```r
core_quantile = 0.80
k = 6
shell_steps = 5
boundary_shell = 2
boundary_gradient_quantile = 1
use_histology = TRUE
histology_alpha = 0.20
rank_bins = 120
rank_equal_sampling = FALSE
```

---

## Example: FW104302

This repository keeps only one example workflow, using **FW104302**.

```r
source("examples/run_example_FW104302.R")
```

Equivalent direct code:

```r
library(SPVS)

setwd("/work/zzh/ZKN/AS模型")

Sys.setenv(
  SPVS_PYTHON = "/work/lzj/miniconda3/envs/scanpy_env/bin/python"
)

res <- run_spvs_on_spatial(
  input = "/data/public/scRNA/Aging/aging_artery/Visium_Slides_Novo_Atherosclerosis.h5ad",
  input_type = "h5ad",
  sample_id = "FW104302",
  out_dir = "PB_SDM/SPVS_package_demo_FW104302"
)
```

---

## Main outputs

SPVS creates `tables/` and `figures/` under the output directory.

### Figures

```text
SPVS_01_BND_IFTCore_PVI_spatial_map.pdf
SPVS_02_plaque_core_probability_map.pdf
SPVS_03_boundary_cell_state_ecology_dotplot.pdf
SPVS_04_boundary_functional_program_dotplot.pdf
SPVS_05_aligned_cell_state_composition_rankplot.pdf
SPVS_06_cell_state_proportion_statistics.pdf
```

`SPVS_05_aligned_cell_state_composition_rankplot.pdf` is exported using a compressed height setting (`10.5 × 2.5 inches`) to generate a flatter, more flatter aligned-composition panel.

### Tables

```text
SPVS_00_core_probability_by_spot.csv
SPVS_02_BND_IFTCore_PVI_by_spot.csv
SPVS_03_boundary_cell_state_ecology_summary.csv
SPVS_04_boundary_functional_programs_summary.csv
SPVS_05_cell_state_composition_rank_binned.csv
SPVS_06_cell_state_proportion_statistics.csv
SPVS_run_inventory.csv
```

---

## Model overview

SPVS is an interpretable spatial model. In standalone mode, the model uses fixed internal molecular programs:

- lipid-necrotic vulnerability,
- proteolytic / matrix-degrading vulnerability,
- inflammatory-core vulnerability,
- hemorrhage / oxidative vulnerability,
- contractile wall / stromal / endothelial counter-programs.

The model then infers plaque-core-like vulnerability states and defines the **BND_IFTCore / PVI** interface using a graph-calibrated spatial transition rule.

---

## Interpretation note

Cell-state composition values are **marker-derived relative cell-state signals**, not literal single-cell counts. They are intended to compare spatial programs across outward non-core, PVI, and inward plaque-core compartments.

---

## Citation

If you use SPVS, please cite the associated manuscript or repository once available.
