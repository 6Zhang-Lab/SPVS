
#' Define BND_IFTCore / PVI from standalone SPVS output
#'
#' PVI is defined as a graph-aware transition band around the internally inferred
#' plaque-core-like state. The method is fully standalone and does not require
#' a reference boundary file.
#' @export
spvs_define_pvi <- function(sp,
                            core_col = "SPVS_PlaqueCore",
                            k = 6,
                            shell_steps = 5,
                            boundary_shell = 2,
                            boundary_gradient_quantile = 1,
                            include_core_edge = FALSE) {
  .pkg(c("dplyr", "FNN", "igraph"))
  data <- sp$data
  if (!(core_col %in% names(data))) stop("core_col not found.", call. = FALSE)

  data$BND_IFTCore <- FALSE
  data$PVI <- FALSE
  data$SPVS_neighbor_core_fraction <- NA_real_
  data$SPVS_core_probability_gradient <- NA_real_
  data$SPVS_shell_to_core <- NA_integer_
  data$SPVS_shell_to_PVI <- NA_integer_
  data$SPVS_compartment <- "Outward non-core region"

  for (s in unique(data$sample)) {
    idx <- which(data$sample == s)
    if (length(idx) <= k + 1) next

    coords <- as.matrix(data[idx, c("x", "y")])
    kk <- min(k, nrow(coords) - 1)
    nn <- FNN::get.knn(coords, k = kk)$nn.index
    edges <- cbind(rep(seq_along(idx), each = kk), as.vector(nn))
    g <- igraph::as.undirected(igraph::graph_from_edgelist(edges, directed = FALSE), mode = "collapse")

    core <- .bool(data[[core_col]][idx])
    prob <- suppressWarnings(as.numeric(data$SPVS_core_probability[idx]))
    prob[!is.finite(prob)] <- 0

    frac <- vapply(seq_along(idx), function(a) mean(core[unique(nn[a, ])], na.rm = TRUE), numeric(1))
    grad <- vapply(seq_along(idx), function(a) {
      nbr <- unique(nn[a, ])
      max(abs(prob[a] - prob[nbr]), na.rm = TRUE)
    }, numeric(1))
    data$SPVS_neighbor_core_fraction[idx] <- frac
    data$SPVS_core_probability_gradient[idx] <- grad

    if (sum(core) > 0) {
      dc <- igraph::distances(g, v = seq_along(idx), to = which(core))
      dcore <- apply(as.matrix(dc), 1, min)
      dcore[!is.finite(dcore)] <- NA_integer_
      data$SPVS_shell_to_core[idx] <- as.integer(pmin(dcore, shell_steps))
    } else {
      dcore <- rep(NA_real_, length(idx))
    }

    grad_thr <- stats::quantile(grad[!core], boundary_gradient_quantile, na.rm = TRUE)
    if (!is.finite(grad_thr)) grad_thr <- 0

    # Standalone calibrated boundary band:
    # non-core spots within the first graph shells from core and with either
    # direct core-neighbor contact or sufficiently high local SPVS-probability gradient.
    pvi <- (!core) &
      is.finite(dcore) &
      dcore > 0 &
      dcore <= boundary_shell &
      (frac > 0 | grad >= grad_thr)

    if (isTRUE(include_core_edge)) {
      core_edge <- core & frac < 1
      pvi <- pvi | core_edge
    }

    data$BND_IFTCore[idx] <- pvi
    data$PVI[idx] <- pvi

    if (sum(pvi) > 0) {
      dp <- igraph::distances(g, v = seq_along(idx), to = which(pvi))
      data$SPVS_shell_to_PVI[idx] <- as.integer(pmin(apply(as.matrix(dp), 1, min), shell_steps))
    }

    comp <- rep("Outward non-core region", length(idx))
    comp[core] <- "Inward plaque-core region"
    comp[pvi] <- "PVI"
    data$SPVS_compartment[idx] <- comp
  }

  data$SPVS_compartment <- factor(data$SPVS_compartment, levels = .compartment_levels)
  sp$data <- data
  attr(sp, "SPVS_boundary_mode") <- "standalone_graph_calibrated_BND_IFTCore"
  sp
}
