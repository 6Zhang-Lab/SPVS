# SPVS

## Final standalone release

- Provides a fully standalone SPVS workflow.
- Keeps FW104302 as the only example workflow.
- Uses tuned standalone default parameters:
  - core_quantile = 0.80
  - k = 6
  - shell_steps = 5
  - boundary_shell = 2
  - boundary_gradient_quantile = 1
  - use_histology = TRUE
  - histology_alpha = 0.20
  - rank_bins = 120
  - rank_equal_sampling = FALSE
- Compresses `SPVS_05_aligned_cell_state_composition_rankplot.pdf` height to 2.5 inches while keeping width at 10.5 inches.
- Provides GitHub-ready README, example script, LICENSE, NEWS, .gitignore, and QuickStart.

- `SPVS_05_aligned_cell_state_composition_rankplot.pdf` export size is `10.5 × 2.5 inches`.
