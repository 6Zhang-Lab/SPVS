# SPVS QuickStart

## 1. Install

```r
install.packages(c(
  "dplyr", "tidyr", "readr", "ggplot2", "stringr",
  "scales", "FNN", "igraph", "Matrix", "magrittr"
))

install.packages("SPVS_FINAL.tar.gz", repos = NULL, type = "source")
```

## 2. Configure Python for H5AD

```r
Sys.setenv(SPVS_PYTHON = "/path/to/python_with_anndata")
```

## 3. Run SPVS

```r
library(SPVS)

res <- run_spvs_on_spatial(
  input = "/path/to/spatial_sample.h5ad",
  input_type = "h5ad",
  sample_id = "Sample01",
  out_dir = "SPVS_results"
)
```

## 4. FW104302 example

```r
source("examples/run_example_FW104302.R")
```

## 5. Outputs

The main figures are:

- `SPVS_01_BND_IFTCore_PVI_spatial_map.pdf`
- `SPVS_02_plaque_core_probability_map.pdf`
- `SPVS_03_boundary_cell_state_ecology_dotplot.pdf`
- `SPVS_04_boundary_functional_program_dotplot.pdf`
- `SPVS_05_aligned_cell_state_composition_rankplot.pdf`
- `SPVS_06_cell_state_proportion_statistics.pdf`
