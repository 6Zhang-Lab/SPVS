# Beginner QuickStart

```r
library(SPVS)

Sys.setenv(SPVS_PYTHON = "/path/to/python_with_anndata")

res <- run_spvs_on_spatial(
  input = "/path/to/spatial_object.h5ad",
  input_type = "h5ad",
  sample_id = "Sample01",
  out_dir = "SPVS_results"
)
```
